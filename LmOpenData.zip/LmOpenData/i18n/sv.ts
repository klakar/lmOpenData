<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="sv_SE" sourcelanguage="">
<context>
    <name>LmOpenData</name>
    <message>
        <location filename="lm_open_data.py" line="187"/>
        <source>&amp;LM Open Data WMTS</source>
        <translation>&amp;LM Öppna Data WMTS</translation>
    </message>
    <message>
        <location filename="lm_open_data.py" line="96"/>
        <source>Error!</source>
        <translation>Fel!</translation>
    </message>
    <message>
        <location filename="lm_open_data.py" line="96"/>
        <source>Layer has no valid token... Try again!</source>
        <translation>Saknar giltig token... Försök igen!</translation>
    </message>
    <message>
        <location filename="lm_open_data.py" line="177"/>
        <source>Topographic Map</source>
        <translation>Topografisk Karta</translation>
    </message>
    <message>
        <location filename="lm_open_data.py" line="209"/>
        <source>LM Topographic CC-BY</source>
        <translation>LM Topografisk CC-BY Lantmäteriet</translation>
    </message>
</context>
<context>
    <name>LmOpenDataDialogBase</name>
    <message>
        <location filename="lm_open_data_dialog_base.ui" line="14"/>
        <source>LM Open Data WMTS</source>
        <translation>LM Öppna Data WMTS</translation>
    </message>
    <message>
        <location filename="lm_open_data_dialog_base.ui" line="42"/>
        <source>Personal Swedish National Land Survey Token Key:</source>
        <translation>Personlig Token från Lantmäteriet</translation>
    </message>
    <message>
        <location filename="lm_open_data_dialog_base.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Get Token at: &lt;a href=&quot;https://opendata.lantmateriet.se/#register&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://opendata.lantmateriet.se/#register&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Registrera dig: &lt;a href=&quot;https://opendata.lantmateriet.se/#register&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://opendata.lantmateriet.se/#register&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
</TS>
